## ----eval=FALSE----------------------------------------------------------
#  utils::vignette(topic = "ars", package = "ars")

## ----echo=TRUE, cache=TRUE-----------------------------------------------
require(ars)
# Set the seed for reproducibility
set.seed(0)

# Generate 1000 standard normal N(0,1) random samples from the R 'dnorm' function
dnorm1000 <- ars(100,g=dnorm,D=c(-Inf,Inf))

# Produce the histogram of the sampled points to check that the output looks
# valid
hist(dnorm1000, breaks=30, main="1000 points sampled from N(0,1)")

## ---- fig.show='hold'----------------------------------------------------
plot(1:10)
plot(10:1)

## ---- echo=FALSE, results='asis'-----------------------------------------
knitr::kable(head(mtcars, 10))

